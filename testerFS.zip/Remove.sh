#!/bin/bash
#
#
# usuwanie testowych plików
#
#
#
#
#
echo `rm -i tmp_File`
echo `rm -r test`

