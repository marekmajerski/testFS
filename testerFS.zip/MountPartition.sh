#!/bin/bash
#

echo "   __     __)                    __     __)                          	"
echo "  (, /|  /|              /)     (, /|  /|       ,             /)   , 	"
echo "    / | / |  _   __   _ (/_       / | / |  _       _  __  _  (/_     	"
echo " ) /  |/  |_(_(_/ (__(/_/(__   ) /  |/  |_(_(_ /__(/_/ (_/_)_/(___(_ 	"
echo "(_/   '                       (_/   '       .-/                      	"


mkdir -p mkdir -p /home/majer/Pulpit/dysk
mount /dev/sdb1 /home/majer/Pulpit/dysk
