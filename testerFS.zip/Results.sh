#!/bin/bash
#Funkcja tworząca plik html z wynikami <początki awk>
#funkcja ta przyjmuje informacje o wielkości pliku, ich ilości a także o wyniku

#	echo " <html> " > tab.html
#	echo " <title> Wyniki tworzenia plików <title>" >> tab.html
	echo " <body> " >> tab.html
	echo " <b> Wynik tworzenia " $7 " plikow o wielkości " $8 " bajtów dla systemu plików: ext3</b><br><br>" >> tab.html
	echo " <table border=1> " >> tab.html 
	echo " <tr><td>"$1"</td>" "<td>"$2"</td></tr>" "<tr><td>"$5"</td>" "<td>"$6"</td></tr> " >> tab.html
	echo " </table> " >> tab.html
	echo " </body> " >> tab.html
